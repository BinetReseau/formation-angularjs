alert('hello');

var hello = 'world';
if (hello == 'world') {
    console.log(hello);
}
