'use strict';

angular.module('brFirstApp')
    .controller('HomeCtrl', function ($scope, $resource) {
        $scope.nom = "Basile";
        $scope.membres = ["Basile", "Guillaume", "Camille", "Théophane"];
    })
;
